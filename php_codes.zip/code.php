<?php
session_start(); 
include './conn.php';
if(isset($_POST['register']))
{
    $fullname=mysqli_real_escape_string($conn,$_POST['fullname']);
    $username=mysqli_real_escape_string($conn,$_POST['username']);
    $email=mysqli_real_escape_string($conn,$_POST['email']);
    $password=mysqli_real_escape_string($conn,$_POST['password']);
    $cpassword=mysqli_real_escape_string($conn,$_POST['cpassword']);
    if($password == $cpassword)
    {
        $checkusername="SELECT * FROM user WHERE username='$username'";
        $checkusername_res=mysqli_query($conn,$checkusername);
        if(mysqli_num_rows($checkusername_res)>0)
        {
            $_SESSION['message']="Sorry UserName Already Exists!!";
            header("Location: ../../register.php");
            exit(0);
        }
        else
        {
            $checkemail="SELECT * FROM user WHERE email='$email'";
            $checkemail_res=mysqli_query($conn,$checkemail);
            if(mysqli_num_rows($checkemail_res)>0) 
            {
                $_SESSION['message']="Sorry UserName Already Exists!!";
            header("Location: ../../register.php");
            exit(0);
            }
            else
            {
                $reg_user="INSERT INTO `user`( `fullname`, `username`, `email`, `password`) VALUES 
                ('$fullname','$username','$email','$password')";
                $reg_user_res=mysqli_query($conn,$reg_user);
                if($reg_user_res)
                {
                    header("Location: ../../login.php");
                    exit(0);
                }
                else
                {
                    $_SESSION['message']="Sorry Something Got Wrong!!";
                    header("Location: ../../register.php");
                    exit(0);
                }
            }
        }
    }
    else
    {
        $_SESSION['message']="Sorry Your Password Do Not Match!!";
        header("Location: ../../register.php");
        exit(0);
    }
}
//login_code
if(isset($_POST['login']))
{
    $email=mysqli_escape_string($conn,$_POST['email']);
    $password=mysqli_escape_string($conn,$_POST['password']);
    $login="SELECT * FROM user WHERE email='$email' AND password='$password' LIMIT 1";
    $login_res=mysqli_query($conn,$login);
    if(mysqli_num_rows($login_res)>0) 
    {
        foreach($login_res as $data)
        {
            $user_id = $data['id'];
            $user_name = $data['username'];
            $user_email = $data['email'];
            $role_as=$data['role_as'];
        }
        $_SESSION['auth']= true;
        $_SESSION['auth_role']="$role_as";
        $_SESSION['auth_user']=[
            'user_id'=>$user_id,
            'user_name'=>$user_name,
            'user_email'=>$user_email,
        ];
        if($_SESSION['auth_role']=='admin')
        {
            header("Location:../index.php");
            exit(0);
        }
        elseif($_SESSION['auth_role']=='medical_doctor')//user
        {
            header("Location: ../index.php");
            exit(0);
        }
        elseif($_SESSION['auth_role']=='maternal_doctor')//user
        {
            header("Location: ../index.php");
            exit(0);
        }
        elseif($_SESSION['auth_role']=='emergency_ward')//user
        {
            header("Location: .../index.php");
            exit(0);
        }
    }
    else
    {
        $_SESSION['message']="Invalid User!!";
        header("Location: ../../login.php");
        exit(0);
    }
}
//logout_code
if(isset($_POST['logout']))
{
    unset($_SESSION['auth']);
    unset($_SESSION['auth_role']);
    unset($_SESSION['auth_user']);
    $_SESSION['message']="Logged Out Successfully!";
    header("Location: ../../login.php");
    exit(0);
}
//add_users_code
if(isset($_POST['add_user']))
{
    $fullname=mysqli_real_escape_string($conn,$_POST['fullname']);
    $username=mysqli_real_escape_string($conn,$_POST['username']);
    $email=mysqli_real_escape_string($conn,$_POST['email']);
    $password=mysqli_real_escape_string($conn,$_POST['password']);
    $role_as=$_POST['role_as'];
    $checkuseremail="SELECT email FROM user WHERE email='$email'";
    $checkuseremail_res=mysqli_query($conn,$checkuseremail);
    if(mysqli_num_rows($checkuseremail_res)>0) 
    {
        header("Location: ../users.php");
        exit(0);
    }
    else
    {
        $checkuseruname="SELECT username FROM user WHERE username='$username'";
        $checkusernuname_res=mysqli_query($conn,$checkusername);
        if(mysqli_num_rows($checkusernuname_res)>0) 
        {
            header("Location: ../users.php");
            exit(0);
        }
        else
        {
            $adduser="INSERT INTO `user`( `fullname`, `username`, `email`, `password`, `role_as`) VALUES 
            ('$fullname','$username','$email','$password','$role_as')";
            $adduser_res=mysqli_query($conn,$adduser);
            if($adduser_res)
            {
                header("Location: ../users.php");
                exit(0);
            }
            else
            {
                header("Location: ../users.php");
                exit(0);
            }
        }
    }
}
//edit_user
if(isset($_POST['edit_user']))
{
    $id=$_POST['id'];
    $fullname=$_POST['fullname'];
    $username=$_POST['username'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $role_as=$_POST['role_as'];
    $checkeditemail="SELECT * FROM user WHERE email='$email' LIMIT 1";
    $checkeditemail_res=mysqli_query($conn,$checkeditemail);
    $edituser="UPDATE `user` SET `fullname`='$fullname',`username`='$username',`email`='$email',`password`='$password',`role_as`='$role_as' WHERE id='$id' ";
            $edituser_res=mysqli_query($conn,$edituser);
            if($edituser_res)
            {
                header("Location: ../users.php");
                exit(0);
            }
            else
            {
                header("Location: ../users.php");
                exit(0);
            }
}
//delete_user
if(isset($_POST['deleteadmin']))
{
    $id=$_POST['deleteadmin'];
    $delete="UPDATE user SET status='block' WHERE id='$id'";
    $delete_res=mysqli_query($conn,$delete);
    if($delete_res)
    {
        header("Location: ../users.php");
        exit(0);
    }
    else
    {
        header("Location: ../users.php");
        exit(0);
    }
}
if(isset($_POST['add_data']))
{
    $fullname=$_POST['fullname'];
    $age=$_POST['age'];
    $sex=$_POST['sex'];
    $address=$_POST['address'];
    $disease_type=$_POST['disease_type'];
    $add_data="INSERT INTO `daily`( `fullname`, `age`, `sex`, `address`, `disease_type`) VALUES ('$fullname','$age','$sex','$address','$disease_type')";
    $add_data_res=mysqli_query($conn,$add_data);
    if($add_data_res)
    {
        header("Location: ../daily.php");
        exit(0);
    }
    else{
        header("Location: ../daily.php");
        exit(0);
    }
}
if(isset($_POST['edit_data']))
{
    $id=$_POST['id'];
    $fullname=$_POST['fullname'];
    $age=$_POST['age'];
    $sex=$_POST['sex'];
    $address=$_POST['address'];
    $disease_type=$_POST['disease_type'];
    $edit_data="UPDATE `daily` SET `fullname`='$fullname',`age`='$age',`sex`='$sex',`address`='$address',`disease_type`='$disease_type' WHERE id='$id'";
    $edit_data_res=mysqli_query($conn,$edit_data);
    if($add_data_res)
    {
        header("Location: ../daily.php");
        exit(0);
    }
    else{
        header("Location: ../daily.php");
        exit(0);
    }
}
if(isset($_POST['add_emergency']))
{
    $fullname=$_POST['fullname'];
    $age=$_POST['age'];
    $sex=$_POST['sex'];
    $address=$_POST['address'];
    $emergency_case=$_POST['emergency_case'];
    $add_emergency="INSERT INTO `emergency`(`fullname`, `age`, `sex`, `address`, `emergecy_case`) VALUES ('$fullname','$age','$sex','$address','$emergency_case')";
    $add_emergency_res=mysqli_query($conn,$add_emergency);
    if($add_emergency_res)
    {
        header("Location: ../emergency.php");
        exit(0);
    }
    else{
        header("Location: ../emergency.php");
        exit(0);
    }
}
//edit_emergency
if(isset($_POST['edit_emergency']))
{
    $id=$_POST['id'];
    $fullname=$_POST['fullname'];
    $age=$_POST['age'];
    $sex=$_POST['sex'];
    $address=$_POST['address'];
    $emergency_case=$_POST['emergency_case'];
    $edit_emergency="UPDATE `emergency` SET `fullname`='$fullname',`age`='$age',`sex`='$sex',`address`='$address',`emergency_case`='$emergency_case' WHERE `id`='$id'";
    $edit_emergency_res=mysqli_query($conn,$edit_emergency);
    if($edit_emergency_res)
    {
        header("Location: ../emergency.php");
        exit(0);
    }
    else
    {
        header("Location: ../emergency.php");
        exit(0);
    }
}
//delete_emergency
if(isset($_POST['delemergency']))
{
    $id=$_POST['delemergency'];
    $delete_emergency="DELETE FROM `emergency` WHERE id='$id'";
    $delete_emergency_res=mysqli_query($conn,$delete_emergency);
    if($delete_emergency_res)
    {
        header("Location: ../emergency.php");
        exit(0);
    }
    else
    {
        header("Location: ../emergency.php");
        exit(0);
    }
}
//add_maternal
if(isset($_POST['add_maternal']))
{
    $fullname=$_POST['fullname'];
    $age=$_POST['age'];
    
}
?>