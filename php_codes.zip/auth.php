<?php 

if(!isset($_SESSION['auth']))
{
    $_SESSION['message']="You Have To Login!!";
    header("Location:../login.php");
    exit(0);
}
else
{
    if($_SESSION['auth_role']!="admin" && $_SESSION['auth_role']!="medical_doctor" && $_SESSION['auth_role']!="maternal" && $_SESSION['auth_role'] == "emergency_ward"
    && $_SESSION['auth_role']!="refere" )
    {
        $_SESSION['message']="Sorry You Are Not Authorized As Admin";
        header("Location:../../login.php");
        exit(0);
    }
}
?>